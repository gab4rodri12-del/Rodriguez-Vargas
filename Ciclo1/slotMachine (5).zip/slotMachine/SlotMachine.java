
/**
 * Simular una maquina tragamonedas.
 * 
 * @author (RodriguezR-VargasC) 
 * @version (1.0 22/08/2026)
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class SlotMachine
{
    private Rectangle body;
    private boolean visible;
    private boolean lastOperationOk;
    private ArrayList<Wheel> wheels;
    private ArrayList<String> symbols;
    public SlotMachine()
    {
        body = new Rectangle();
        body.changeSize(220,250);
        body.moveHorizontal(-40);
        body.moveVertical(30);
        body.changeColor("black");
        
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();
        visible = false;
        
    }
    public void addWheel(int pos)
    {
        int position = adjustedAddPosition(pos);
        Wheel wheel = new Wheel();
        
        wheels.add(position - 1, wheel);
        arrangeWheels();
        
        if (visible){
            wheel.makeVisible(); 
        }
        operationSucceeded();
        
    }
    
    private void arrangeWheels()
    {
        for (int i = 0; i < wheels.size(); i++){
            wheels.get(i).setPosition(i + 1);
        }
    }
    private int adjustedAddPosition(int pos)
    {
        if (pos < 1){
            return 1;
        }
        if (pos > wheels.size()+1){
            return wheels.size() +1;
        }
        return pos;
        }
    public void delWheel(int pos)
    {
        if (wheels.size() > 0){
            int position =adjustedWheelPosition(pos);
            
            Wheel wheel = wheels.get(position-1);
            wheel.makeInvisible();
            
            wheels.remove  (position - 1);
            
            arrangeWheels();
            
            operationSucceeded();
        }
        else{
            operationFailed("no hay ninguna rueda para eliminar");
        }
    }
    private int adjustedWheelPosition(int pos)
    {
        if(pos < 1){
                return 1;
        }
        if (pos > wheels.size()){
            return wheels.size();
        }
        return pos;
    }
    public void addSymbol(int pos, String color)
    {
        if (!symbols.contains(color)){
        int position = adjustedSymbolAddPosition(pos);
        symbols.add(position - 1, color);
        
        operationSucceeded();
        }
        
        else{
            operationFailed("El simbolo ya existe");
        }
    }
    private int adjustedSymbolAddPosition(int pos)
    {
        if (pos < 1){
            return 1;
        }
        if (pos >symbols.size() +1 ){
            return symbols.size() + 1;
        }
        return pos;
    }
    public void delSymbol(String symbol)
    {
        if (symbols.contains(symbol)){
            symbols.remove(symbol);
            operationSucceeded();
        }
        
        else{
            operationFailed("El simbolo no existe");
        }
    }
    public void placeSymbol(int wheel, String symbol)
    {
        if (wheels.isEmpty()){
            operationFailed("no hay ruedas");
        }
        
        else if (!symbols.contains(symbol)){
            operationFailed("el simbolo no existe");
        }
        else{
            int position = adjustedWheelPosition(wheel);
            wheels.get(position - 1).setSymbol(symbol);
            
            operationSucceeded();
            updateJackpotAppearence();
            redrawWheels(); 
        }
    }
    private void redrawWheels()
    {
        if (visible)
        {
            for (Wheel wheel : wheels )
            {
                wheel.makeVisible();
            }
        }
    }
    public void spin(int wheel)
    {
        if (wheels.isEmpty())
        {
            operationFailed("no hay ruedas");
        }
        
        else if (symbols.isEmpty()){
            operationFailed("no hay simbolos");
        }
        
        else{
            int randomIndex = (int) (Math.random() * symbols.size());
            String randomSymbol = symbols.get(randomIndex);
            
            placeSymbol(wheel, randomSymbol);
        }
    }
    public void spin()
    {
        if (wheels.isEmpty()){
            operationFailed("no hay ruedas");
        }
        
        else if (symbols.isEmpty()){
            operationFailed("no hay simbolos");
        }
        
        else{
            for (int i = 1; i <= wheels.size(); i++){
            spin(i);
            }
        }
    }
    public String[] symbols()
    {
        return symbols.toArray(new String[0]);
    }
    public int distinctSymbols()
    {
        return symbols.size();
    }
    public String[] configuration()
    {
        String[] configuration = new String [wheels.size()];
        
        for (int i = 0; i < wheels .size(); i++) {
            configuration[i] = wheels.get(i).getSymbol();
        }
        
        return configuration;
    }
    private void updateJackpotAppearence()
    {
        if (isJackpot()){
            body.changeColor("green");
        }
        else{
            body.changeColor("black");
        }
    }
    public boolean isJackpot()
    {
        if (wheels.isEmpty()){
            return false;
        }
        
        String firstSymbol = wheels.get(0).getSymbol();
        
        if (firstSymbol == null){
            return false;
        }
        
        for (Wheel wheel : wheels){
            if (!firstSymbol.equals(wheel.getSymbol())){
                return false;
            }
        }
        return true;
    }
    
    public void makeVisible()
    {    
        body.makeVisible();
        
        for (Wheel wheel : wheels) {
            wheel.makeVisible();
        }
        
        visible = true;
    }
    
    public void makeInvisible()
    {
        body.makeInvisible();
        
        for (Wheel wheel : wheels){
            wheel.makeInvisible();
        }
        visible = false;
    }
    
    public void exit()
    {
        makeInvisible();
        operationSucceeded();
    }
      
    public boolean ok()
    {
        return lastOperationOk;
    }
    
    private void operationFailed(String message)
    {
        lastOperationOk = false;
        
        if (visible){
            JOptionPane.showMessageDialog(null, message);
        }
    }
    
    private void operationSucceeded()
    {
        lastOperationOk = true;
    }
    }
